Java Producer-Consumer Problem

Files:
- Main.java: Complete Producer-Consumer program using LinkedList, synchronized,
  wait(), and notify().
- README.txt: Run instructions.

Run:
1. Save/open the Java file as Main.java.
2. Open a terminal in the same folder.
3. Compile: javac Main.java
4. Run: java Main

The shared buffer capacity is 2. Producer and consumer run indefinitely.
Stop the program with Ctrl+C in the terminal.
